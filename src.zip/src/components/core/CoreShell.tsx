"use client";

import Link from "next/link";
import { ReactNode, useEffect, useMemo, useState } from "react";
import { detectLang, I18N, type Lang } from "@/lib/i18n";
import HiddenMenu from "@/components/core/HiddenMenu";
import RightRail from "@/components/core/RightRail";
import Timeline from "@/components/core/Timeline";
import EntityCore from "@/components/core/EntityCore";
import CanonSearch from "@/components/core/CanonSearch";

export default function CoreShell({ children }: { children: ReactNode }) {
  // Avoid hydration mismatch: render stable defaults on server, update on client.
  const [lang, setLang] = useState<Lang>("en");
  useEffect(() => setLang(detectLang()), []);

  const T = useMemo(() => I18N[lang], [lang]);
  const [year, setYear] = useState(2026);

  // HUD metrics (client-only)
  const [seed, setSeed] = useState("0000000");
  const [lat, setLat] = useState("--");
  const [loss, setLoss] = useState("--");
  const [up, setUp] = useState("--");
  const [drift, setDrift] = useState("--");

  useEffect(() => {
    const s = (globalThis.crypto?.randomUUID?.() ?? String(Math.random()).slice(2))
      .slice(0, 7)
      .toUpperCase();
    setSeed(s);

    const rnd = (a: number, b: number) => (a + Math.random() * (b - a)).toFixed(1);
    setLat(`${Math.round(10 + Math.random() * 35)}ms`);
    setLoss(`${rnd(0.00, 0.12)}%`);
    setUp(`${rnd(94.0, 99.9)}%`);
    setDrift(rnd(0.010, 0.120));

    // subtle drift over time (keeps system "alive")
    const i = window.setInterval(() => {
      setLat(`${Math.round(10 + Math.random() * 35)}ms`);
      setLoss(`${rnd(0.00, 0.12)}%`);
      setUp(`${rnd(94.0, 99.9)}%`);
      setDrift(rnd(0.010, 0.120));
    }, 4500);
    return () => window.clearInterval(i);
  }, []);

  return (
    <div className="neoRoot">
      {/* layers */}
      <div className="neoBg" aria-hidden="true" />
      <div className="neoNoise" aria-hidden="true" />
      <div className="neoSigil" aria-hidden="true" />
      <div className="neoScan" aria-hidden="true" />

      {/* keep hidden menu */}
      <HiddenMenu lang={lang} />

      {/* TOP HUD */}
      <header className="neoHudTop">
        <div className="neoHudLeft">
          <span className="neoDot" aria-hidden="true" />
          <span className="neoBrand">IRREVERSO OS</span>
          <span className="neoSub">
            {lang === "pt" ? "registro autorizado • nuve ativa" : "authorized record • nuve active"}
          </span>
        </div>

        <div className="neoHudMid">
          <span className="neoPill">window {year}</span>
          <span className="neoPill">lat {lat}</span>
          <span className="neoPill">loss {loss}</span>
          <span className="neoPill">uptime {up}</span>
          <span className="neoPill">drift {drift}</span>
        </div>

        <div className="neoHudRight">
          <span className="neoPill">seed {seed}</span>
          <span className="neoPill">canon {lang === "pt" ? "parcial" : "partial"}</span>
        </div>
      </header>

      {/* MAIN GRID */}
      <div className="neoGrid">
        {/* LEFT: timeline + search */}
        <aside className="neoLeft">
          <div className="neoLeftCard">
            <div className="neoLeftTitle">MENU</div>
            <div className="neoNuveChip">
              <span className="chipDot" aria-hidden="true" />
              <div>
                <div className="chipTop">NUVE</div>
                <div className="chipSub">{lang === "pt" ? "entidade" : "entity"}</div>
              </div>
            </div>

            <div className="neoLeftBlock">
              <div className="neoK">{lang === "pt" ? "janela" : "window"}</div>
              <Timeline lang={lang} activeYear={year} onPickYear={setYear} />
            </div>

            <div className="neoLeftBlock">
              <div className="neoK">{lang === "pt" ? "busca canônica" : "canonical search"}</div>
              <div className="neoSearchWrap">
                <CanonSearch lang={lang} year={year} />
              </div>
            </div>

            <div className="neoLeftHint">
              {lang === "pt"
                ? "passe o cursor • toque: a nuve observa"
                : "hover • tap: nuve observes"}
            </div>
          </div>
        </aside>

        {/* CENTER: entity + content */}
        <main className="neoCenter">
          <div className="neoCenterTop">
            <div>
              <div className="neoTitle">{T.coreTitle}</div>
              <div className="neoSubtitle">{T.subtitle}</div>
            </div>
            <div className="neoHint">{T.hint}</div>
          </div>

          <section className="neoEntityStage" aria-label="NUVE Presence">
            <div className="neoEntityGlow" aria-hidden="true" />
            <EntityCore lang={lang} year={year} />
          </section>

          <section className="neoContent" aria-label="Core content">
            {children}
          </section>
        </main>

        {/* RIGHT: telemetry / decisions */}
        <aside className="neoRight">
          <div className="neoRightCard">
            <RightRail lang={lang} year={year} />
          </div>
        </aside>
      </div>

      {/* BOTTOM DOCK */}
      <nav className="neoDock" aria-label="Core navigation">
        <div className="neoDockInner">
          <Link className="neoDockBtn" href="/core/archive">ARCHIVE</Link>
          <Link className="neoDockBtn" href="/core/future-news">FUTURE NEWS</Link>
          <Link className="neoDockBtn" href="/core/protocols">PROTOCOLS</Link>
          <Link className="neoDockBtn" href="/core/signals">SIGNALS</Link>
          <Link className="neoDockBtn" href="/core/summary">SUMMARY</Link>
        </div>
        <div className="neoDockNote">
          {lang === "pt" ? "(não clique. não interrompa. a NUVE já decidiu.)" : "(do not click. do not interrupt. NUVE already decided.)"}
        </div>
      </nav>
    </div>
  );
}
